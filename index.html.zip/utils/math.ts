
import { Fraction, MixedNumber, Problem } from './types';

const gcd = (a: number, b: number): number => {
  return b === 0 ? a : gcd(b, a % b);
};

export const simplifyFraction = (fraction: Fraction): Fraction => {
  if (fraction.numerator === 0) {
    return { numerator: 0, denominator: 1 };
  }
  const commonDivisor = gcd(fraction.numerator, fraction.denominator);
  return {
    numerator: fraction.numerator / commonDivisor,
    denominator: fraction.denominator / commonDivisor,
  };
};

export const toMixedNumber = (fraction: Fraction): MixedNumber => {
  const whole = Math.floor(fraction.numerator / fraction.denominator);
  const newNumerator = fraction.numerator % fraction.denominator;

  if (newNumerator === 0) {
    return { whole, numerator: 0, denominator: 1 };
  }

  const simplified = simplifyFraction({ numerator: newNumerator, denominator: fraction.denominator });

  return {
    whole,
    numerator: simplified.numerator,
    denominator: simplified.denominator,
  };
};

const generateRandomNumber = (min: number, max: number): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

export const generateProblem = (): Problem => {
  const type = Math.random() > 0.5 ? 'fraction_division' : 'natural_division';
  
  let operand1: number | Fraction;
  let operand2: Fraction;
  let resultFraction: Fraction;

  if (type === 'fraction_division') {
    operand1 = {
      numerator: generateRandomNumber(1, 9),
      denominator: generateRandomNumber(2, 9),
    };
    operand2 = {
      numerator: generateRandomNumber(1, 9),
      denominator: generateRandomNumber(2, 9),
    };
    // Ensure we don't divide by a fraction that simplifies to a whole number easily
    if (operand2.numerator % operand2.denominator === 0) {
        operand2.denominator += 1;
    }

    resultFraction = {
      numerator: operand1.numerator * operand2.denominator,
      denominator: operand1.denominator * operand2.numerator,
    };
  } else { // natural_division
    operand1 = generateRandomNumber(2, 12);
    operand2 = {
      numerator: generateRandomNumber(1, 9),
      denominator: generateRandomNumber(2, 9),
    };
    // Ensure we don't divide by a fraction that simplifies to a whole number easily
    if (operand2.numerator % operand2.denominator === 0) {
        operand2.denominator += 1;
    }

    resultFraction = {
      numerator: operand1 * operand2.denominator,
      denominator: operand2.numerator,
    };
  }
  
  const answer = toMixedNumber(resultFraction);
  
  return { operand1, operand2, answer };
};
