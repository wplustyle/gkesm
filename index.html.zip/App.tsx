import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GameState, Player, Tile, ItemType, Problem, Fraction, MixedNumber } from './types';
import { generateProblem } from './utils/math';

const PLAYER_COLORS = [
  { color: '#f87171', bg: 'bg-red-400', text: 'text-red-500', border: 'border-red-400' },
  { color: '#60a5fa', bg: 'bg-blue-400', text: 'text-blue-500', border: 'border-blue-400' },
  { color: '#4ade80', bg: 'bg-green-400', text: 'text-green-500', border: 'border-green-400' },
  { color: '#facc15', bg: 'bg-yellow-400', text: 'text-yellow-500', border: 'border-yellow-400' },
  { color: '#a78bfa', bg: 'bg-purple-400', text: 'text-purple-500', border: 'border-purple-400' },
];

const ITEM_DESCRIPTIONS: Record<ItemType, { name: string; description: string; icon: string; }> = {
  [ItemType.CLAIM_EMPTY]: { name: '빈칸 차지', description: '상대방이 차지하지 않은 빈칸을 직접 골라 내 칸으로 만듭니다.', icon: '🗺️' },
  [ItemType.STEAL_TILE]: { name: '상대방 칸 뺏기', description: '상대방이 차지한 칸 하나를 뺏어옵니다.', icon: '⚔️' },
  [ItemType.DOUBLE_POINTS]: { name: '점수 2배', description: '이번 턴에 얻는 점수가 2배가 됩니다 (총 2점).', icon: '✨' },
  [ItemType.TRIPLE_POINTS]: { name: '점수 3배', description: '이번 턴에 얻는 점수가 3배가 됩니다 (총 3점).', icon: '🌟' },
  [ItemType.BOMB]: { name: '꽝', description: '아무 효과도 없습니다. 아쉽지만, 다음 기회에!', icon: '💣' },
  [ItemType.SWAP_SCORES]: { name: '점수 교환', description: '다른 플레이어와 점수를 통째로 바꿉니다.', icon: '🔄' },
  [ItemType.STEAL_SCORE]: { name: '점수 뺏기', description: '다른 플레이어의 점수 2점을 뺏어옵니다.', icon: '💰' },
};


const BOARD_SIZE = 5;

interface FractionDisplayProps {
  value: number | Fraction;
}

const FractionDisplay: React.FC<FractionDisplayProps> = ({ value }) => {
  if (typeof value === 'number') {
    return <span className="text-6xl font-bold">{value}</span>;
  }
  return (
    <div className="inline-flex flex-col items-center justify-center font-bold text-6xl mx-2">
      <span>{value.numerator}</span>
      <span className="border-t-4 border-gray-800 w-20"></span>
      <span>{value.denominator}</span>
    </div>
  );
};

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.SETUP);
  const [players, setPlayers] = useState<Player[]>([]);
  const [numPlayers, setNumPlayers] = useState<number>(2);
  const [board, setBoard] = useState<Tile[]>([]);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [activeTile, setActiveTile] = useState<Tile | null>(null);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [showSwapModal, setShowSwapModal] = useState(false);
  const [showStealScoreModal, setShowStealScoreModal] = useState(false);
  const [swapTarget, setSwapTarget] = useState<number | null>(null);
  const [stealTarget, setStealTarget] = useState<number | null>(null);
  const [awardedLines, setAwardedLines] = useState<string[]>([]);
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [showCardModal, setShowCardModal] = useState(false);
  const [availableCards, setAvailableCards] = useState<ItemType[]>([]);
  const [selectionMode, setSelectionMode] = useState<'claim' | 'steal' | null>(null);

  const currentPlayer = useMemo(() => players[currentPlayerIndex], [players, currentPlayerIndex]);

  const createBoard = useCallback(() => {
    const newBoard: Tile[] = [];
    for (let i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
      newBoard.push({
        id: i,
        problem: generateProblem(),
        ownerId: null,
      });
    }
    setBoard(newBoard);
  }, []);

  const handleStartGame = (playerNames: string[]) => {
    const newPlayers = playerNames.map((name, i) => ({
      id: i,
      name: name || `Player ${i + 1}`,
      score: 0,
      color: PLAYER_COLORS[i].color,
      tailwindBg: PLAYER_COLORS[i].bg,
      tailwindText: PLAYER_COLORS[i].text,
      tailwindBorder: PLAYER_COLORS[i].border,
    }));
    setPlayers(newPlayers);
    createBoard();
    setCurrentPlayerIndex(0);
    setAwardedLines([]);
    setLastMessage(null);
    setGameState(GameState.PLAYING);
  };
  
  const handleTileClick = (tile: Tile) => {
    if (selectionMode === 'claim') {
      if (tile.ownerId === null) {
        const newBoard = board.map(t => t.id === tile.id ? { ...t, ownerId: currentPlayer.id } : t);
        setBoard(newBoard);
        setLastMessage(`${currentPlayer.name}님이 빈 칸을 차지했습니다!`);
        checkForFiveInARow(newBoard, currentPlayer.id);
        setSelectionMode(null);
        nextTurn();
      }
    } else if (selectionMode === 'steal') {
      if (tile.ownerId !== null && tile.ownerId !== currentPlayer.id) {
        const newBoard = board.map(t => t.id === tile.id ? { ...t, ownerId: currentPlayer.id } : t);
        setBoard(newBoard);
        setLastMessage(`${currentPlayer.name}님이 상대방의 칸을 빼앗았습니다!`);
        checkForFiveInARow(newBoard, currentPlayer.id);
        setSelectionMode(null);
        nextTurn();
      }
    } else {
      if (tile.ownerId !== null) return;
      setActiveTile(tile);
      setShowQuestionModal(true);
    }
  };

  const nextTurn = useCallback(() => {
    setCurrentPlayerIndex((prevIndex) => (prevIndex + 1) % players.length);
  }, [players.length]);
  
  const checkForFiveInARow = useCallback((currentBoard: Tile[], playerId: number) => {
    const getOwner = (r: number, c: number) => {
      if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) return null;
      return currentBoard[r * BOARD_SIZE + c].ownerId;
    };
    let newPoints = 0;
    let newAwardedLines: string[] = [];
  
    for (let i = 0; i < BOARD_SIZE; i++) {
      for (let j = 0; j < BOARD_SIZE; j++) {
        // Horizontal
        if (j <= BOARD_SIZE - 5) {
          const lineKey = `h-${i}-${j}`;
          if (!awardedLines.includes(lineKey) &&
              getOwner(i, j) === playerId && getOwner(i, j+1) === playerId &&
              getOwner(i, j+2) === playerId && getOwner(i, j+3) === playerId && getOwner(i,j+4) === playerId) {
            newPoints += 5;
            newAwardedLines.push(lineKey);
          }
        }
        // Vertical
        if (i <= BOARD_SIZE - 5) {
          const lineKey = `v-${i}-${j}`;
          if (!awardedLines.includes(lineKey) &&
              getOwner(i, j) === playerId && getOwner(i+1, j) === playerId &&
              getOwner(i+2, j) === playerId && getOwner(i+3, j) === playerId && getOwner(i+4, j) === playerId) {
            newPoints += 5;
            newAwardedLines.push(lineKey);
          }
        }
        // Diagonal (down-right)
        if (i <= BOARD_SIZE - 5 && j <= BOARD_SIZE - 5) {
          const lineKey = `dr-${i}-${j}`;
          if (!awardedLines.includes(lineKey) &&
              getOwner(i, j) === playerId && getOwner(i+1, j+1) === playerId &&
              getOwner(i+2, j+2) === playerId && getOwner(i+3, j+3) === playerId && getOwner(i+4, j+4) === playerId) {
            newPoints += 5;
            newAwardedLines.push(lineKey);
          }
        }
        // Diagonal (down-left)
        if (i <= BOARD_SIZE - 5 && j >= 4) {
          const lineKey = `dl-${i}-${j}`;
          if (!awardedLines.includes(lineKey) &&
              getOwner(i, j) === playerId && getOwner(i+1, j-1) === playerId &&
              getOwner(i+2, j-2) === playerId && getOwner(i+3, j-3) === playerId && getOwner(i+4, j-4) === playerId) {
            newPoints += 5;
            newAwardedLines.push(lineKey);
          }
        }
      }
    }
    
    if (newPoints > 0) {
      setPlayers(prev => prev.map(p => p.id === playerId ? { ...p, score: p.score + newPoints } : p));
      setAwardedLines(prev => [...prev, ...newAwardedLines]);
      setLastMessage(`${players[playerId].name}님이 5목을 완성하여 ${newPoints}점 보너스를 획득했습니다!`);
    }
  }, [awardedLines, players]);

  useEffect(() => {
    if (gameState === GameState.PLAYING && board.length > 0 && board.every(tile => tile.ownerId !== null)) {
      setGameState(GameState.GAMEOVER);
    }
  }, [board, gameState]);

  const handleAnswerSubmit = (answer: Partial<MixedNumber>) => {
    if (!activeTile) return;

    const correctAnswer = activeTile.problem.answer;
    const isCorrect = 
      (answer.whole || 0) === correctAnswer.whole &&
      (answer.numerator || 0) === correctAnswer.numerator &&
      answer.denominator === correctAnswer.denominator;
    
    setShowQuestionModal(false);
    
    if (isCorrect) {
      const newBoard = board.map(t => t.id === activeTile.id ? { ...t, ownerId: currentPlayer.id } : t);
      setBoard(newBoard);
      setLastMessage(`${currentPlayer.name}님이 정답을 맞혔습니다! 카드를 선택하세요.`);
      checkForFiveInARow(newBoard, currentPlayer.id);

      // Generate 3 random cards
      const allItems = Object.values(ItemType);
      const shuffled = allItems.sort(() => 0.5 - Math.random());
      setAvailableCards(shuffled.slice(0, 3));
      setShowCardModal(true);
    } else {
      setLastMessage('틀렸습니다! 다음 플레이어에게 턴이 넘어갑니다.');
      nextTurn();
    }
    // activeTile is kept for card selection context, cleared after.
  };

  const handleCardSelect = (item: ItemType) => {
    setShowCardModal(false);
    let pointsThisTurn = 1;
    let message = '';
    let immediateNextTurn = true;

    switch (item) {
        case ItemType.DOUBLE_POINTS:
            pointsThisTurn = 2;
            message = `${currentPlayer.name}님이 2배 점수를 뽑아 ${pointsThisTurn}점을 획득했습니다!`;
            break;
        case ItemType.TRIPLE_POINTS:
            pointsThisTurn = 3;
            message = `${currentPlayer.name}님이 3배 점수를 뽑아 ${pointsThisTurn}점을 획득했습니다!`;
            break;
        case ItemType.BOMB:
            pointsThisTurn = 0;
            message = '꽝! 아쉽지만 점수를 얻지 못했습니다.';
            break;
        case ItemType.SWAP_SCORES:
            pointsThisTurn = 0; // The base point is not awarded
            setShowSwapModal(true);
            immediateNextTurn = false;
            message = '점수 교환! 바꿀 플레이어를 선택하세요.';
            break;
        case ItemType.STEAL_SCORE:
            pointsThisTurn = 0; // The base point is not awarded
            setShowStealScoreModal(true);
            immediateNextTurn = false;
            message = '점수 뺏기! 2점을 뺏어올 플레이어를 선택하세요.';
            break;
        case ItemType.CLAIM_EMPTY:
            pointsThisTurn = 1; // Award base point
            setSelectionMode('claim');
            immediateNextTurn = false;
            message = `${currentPlayer.name}님이 빈 칸 차지를 뽑았습니다! 원하는 빈 칸을 선택하세요. (1점 획득)`;
            break;
        case ItemType.STEAL_TILE:
            pointsThisTurn = 1; // Award base point
            setSelectionMode('steal');
            immediateNextTurn = false;
            message = `${currentPlayer.name}님이 상대방 칸 뺏기를 뽑았습니다! 뺏을 칸을 선택하세요. (1점 획득)`;
            break;
        default:
            message = `${currentPlayer.name}님이 땅을 차지하고 1점을 획득했습니다.`;
            break;
    }

    if (pointsThisTurn > 0) {
        setPlayers(prev => prev.map(p => p.id === currentPlayer.id ? { ...p, score: p.score + pointsThisTurn } : p));
    }
    
    setLastMessage(message);

    if (immediateNextTurn) {
        nextTurn();
    }
    setActiveTile(null);
  };
  
  const handleSwap = () => {
      if (swapTarget === null) return;
      const targetPlayer = players.find(p => p.id === swapTarget);
      if (!targetPlayer) return;

      const currentPlayerScore = currentPlayer.score;
      const targetPlayerScore = targetPlayer.score;
      
      setPlayers(prev => prev.map(p => {
          if (p.id === currentPlayer.id) return { ...p, score: targetPlayerScore };
          if (p.id === swapTarget) return { ...p, score: currentPlayerScore };
          return p;
      }));
      setLastMessage(`${currentPlayer.name}님이 ${targetPlayer.name}님과 점수를 교환했습니다!`);
      setShowSwapModal(false);
      setSwapTarget(null);
      nextTurn();
  };

  const handleStealScore = () => {
    if (stealTarget === null) return;
    const targetPlayer = players.find(p => p.id === stealTarget);
    if (!targetPlayer) return;

    const pointsToSteal = Math.min(targetPlayer.score, 2);

    setPlayers(prev => prev.map(p => {
        if (p.id === currentPlayer.id) return { ...p, score: p.score + pointsToSteal };
        if (p.id === stealTarget) return { ...p, score: p.score - pointsToSteal };
        return p;
    }));
    setLastMessage(`${currentPlayer.name}님이 ${targetPlayer.name}님에게서 ${pointsToSteal}점을 뺏어왔습니다!`);
    setShowStealScoreModal(false);
    setStealTarget(null);
    nextTurn();
  }

  const renderGameSetup = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="bg-white p-8 rounded-2xl shadow-2xl text-center w-full max-w-3xl">
        <h1 className="text-5xl mb-2 text-amber-700 text-pop">분수 나눗셈 땅따먹기</h1>
        <p className="mb-6 text-gray-600 text-xl">6학년 분수 나눗셈 마스터가 되어보세요!</p>
        
        <div className="mb-6 text-left bg-amber-50 p-6 rounded-lg border-2 border-amber-200">
          <h2 className="text-3xl mb-4 text-amber-800 text-pop">✨ 아이템 목록 ✨</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            {Object.values(ItemType).map((item, index) => (
                <div key={item} className="flex items-start space-x-3">
                  <span className="text-4xl mt-1">{ITEM_DESCRIPTIONS[item].icon}</span>
                  <div>
                    <h3 className={`text-2xl font-bold ${PLAYER_COLORS[index % PLAYER_COLORS.length].text} text-pop`}>{ITEM_DESCRIPTIONS[item].name}</h3>
                    <p className="text-md text-gray-700">{ITEM_DESCRIPTIONS[item].description}</p>
                  </div>
                </div>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <label htmlFor="numPlayers" className="block text-2xl font-semibold mb-2 text-gray-700 text-pop">플레이어 수:</label>
          <select id="numPlayers" value={numPlayers} onChange={(e) => setNumPlayers(parseInt(e.target.value))} className="w-full p-3 border-2 border-gray-300 rounded-lg text-2xl">
            <option value="2">2명</option>
            <option value="3">3명</option>
            <option value="4">4명</option>
            <option value="5">5명</option>
          </select>
        </div>
        <button onClick={() => {
            const names = Array.from({ length: numPlayers }, (_, i) => `플레이어 ${i + 1}`);
            handleStartGame(names);
        }} className="w-full bg-amber-400 hover:bg-amber-500 text-white font-bold py-4 px-4 rounded-lg text-3xl transition-transform transform hover:scale-105 text-pop-white">
          게임 시작
        </button>
      </div>
    </div>
  );

  const renderGameOver = () => {
    const winner = players.reduce((prev, current) => (prev.score > current.score) ? prev : current);
    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-8 shadow-2xl text-center transform scale-100 transition-all w-full max-w-lg">
          <h2 className="text-6xl font-bold mb-4 text-yellow-500 text-pop">게임 종료!</h2>
          <h3 className="text-4xl font-semibold mb-6 text-pop">최종 우승자: <span className={`${winner.tailwindText}`}>{winner.name}</span></h3>
          <ul className="space-y-2 mb-8 text-2xl">
            {players.sort((a,b) => b.score - a.score).map(p => (
              <li key={p.id} className="flex justify-between items-center p-3 rounded-lg bg-gray-100">
                <span className={`font-bold ${p.tailwindText} text-pop`}>{p.name}</span>
                <span className="font-semibold">{p.score} 점</span>
              </li>
            ))}
          </ul>
          <button
            onClick={() => setGameState(GameState.SETUP)}
            className="w-full bg-green-400 hover:bg-green-500 text-white font-bold py-3 px-4 rounded-lg text-3xl transition-transform transform hover:scale-105 text-pop-white"
          >
            새 게임 시작하기
          </button>
        </div>
      </div>
    );
  }

  const renderGame = () => (
    <div className="container mx-auto p-4 font-sans">
      <h1 className="text-5xl text-center mb-2 text-amber-700 text-pop">분수 나눗셈 땅따먹기</h1>
       <div className="text-center bg-amber-200 p-3 rounded-lg mb-4 max-w-4xl mx-auto border-2 border-amber-300">
        <h2 className="text-2xl text-pop text-amber-800">📜 게임 규칙</h2>
        <p className="text-md">1. 문제를 맞히면 보드판의 땅 1칸을 차지하며 1점을 얻고, 카드 3장 중 하나를 뽑아 특별 효과를 얻습니다.</p>
        <p className="text-md">2. 가로, 세로, 대각선으로 5칸을 먼저 완성하면 보너스 5점을 얻습니다.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-3">
          <div className="grid grid-cols-5 gap-2 aspect-square bg-amber-200 p-2 rounded-lg shadow-inner">
            {board.map((tile) => {
              const owner = players.find(p => p.id === tile.ownerId);
              const isSelectable = 
                (selectionMode === 'claim' && tile.ownerId === null) ||
                (selectionMode === 'steal' && tile.ownerId !== null && tile.ownerId !== currentPlayer.id);

              return (
                <button
                  key={tile.id}
                  onClick={() => handleTileClick(tile)}
                  disabled={tile.ownerId !== null && !isSelectable}
                  className={`relative aspect-square rounded-md flex items-center justify-center transition-all duration-300 transform
                    ${owner ? `${owner.tailwindBg} text-white` : 'bg-amber-100'}
                    ${tile.ownerId === null && !selectionMode ? 'hover:bg-yellow-200 hover:scale-105 cursor-pointer' : ''}
                    ${isSelectable ? 'cursor-pointer ring-4 ring-offset-2 ring-green-400 animate-pulse' : ''}
                    ${tile.ownerId !== null && !isSelectable ? 'cursor-not-allowed' : ''}
                    `}
                >
                  {owner && <span className="text-5xl text-pop-white">{owner.name.charAt(0)}</span>}
                </button>
              );
            })}
          </div>
        </div>
        <div className="md:col-span-1 bg-white p-4 rounded-lg shadow-lg">
          <h2 className="text-3xl mb-4 border-b-2 pb-2 text-pop text-gray-700">플레이어 정보</h2>
          <div className="space-y-3">
            {players.map((p, index) => (
              <div key={p.id} className={`p-3 rounded-lg border-l-8 transition-all duration-300 ${p.tailwindBorder} ${currentPlayerIndex === index ? 'bg-yellow-200 scale-105 shadow-md' : 'bg-gray-50'}`}>
                <div className="flex justify-between items-center">
                  <span className={`text-2xl font-bold ${p.tailwindText} text-pop`}>{p.name}</span>
                  <span className="text-2xl font-semibold">{p.score} 점</span>
                </div>
                {currentPlayerIndex === index && <div className="text-md font-semibold text-gray-600 mt-1">현재 턴</div>}
              </div>
            ))}
          </div>
          {lastMessage && <div className={`mt-4 p-3 rounded-lg text-center font-semibold text-xl transition-all ${selectionMode ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>{lastMessage}</div>}
        </div>
      </div>
    </div>
  );

  const renderQuestionModal = () => {
    if (!showQuestionModal || !activeTile) return null;
    const { operand1, operand2 } = activeTile.problem;

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const answer: Partial<MixedNumber> = {
        whole: parseInt(formData.get('whole') as string) || 0,
        numerator: parseInt(formData.get('numerator') as string) || 0,
        denominator: parseInt(formData.get('denominator') as string) || 1,
      };
      if (answer.numerator === 0) answer.denominator = 1;
      handleAnswerSubmit(answer);
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 shadow-2xl text-center transform scale-100 transition-all w-full max-w-2xl">
          <h2 className="text-4xl mb-6 text-pop text-gray-800">문제!</h2>
          <div className="flex items-center justify-center mb-8">
            <FractionDisplay value={operand1} />
            <span className="text-6xl font-bold mx-4">÷</span>
            <FractionDisplay value={operand2} />
          </div>
          <p className="mb-4 text-gray-600 font-semibold text-lg">답을 대분수와 기약분수 형태로 입력해주세요.<br/>(자연수인 경우, 첫 칸에만 숫자를 입력하세요.)</p>
          <div className="flex items-center justify-center space-x-2">
            <input type="number" name="whole" min="0" className="w-28 h-28 text-5xl text-center border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200" placeholder="0" />
            <div className="inline-flex flex-col items-center justify-center font-bold text-4xl mx-2">
              <input type="number" name="numerator" min="0" className="w-24 h-20 text-3xl text-center border-2 border-gray-300 rounded-lg" />
              <span className="border-t-4 border-gray-800 w-24 my-1"></span>
              <input type="number" name="denominator" min="1" className="w-24 h-20 text-3xl text-center border-2 border-gray-300 rounded-lg" />
            </div>
          </div>
          <button type="submit" className="mt-8 w-full bg-blue-400 hover:bg-blue-500 text-white font-bold py-3 px-4 rounded-lg text-3xl text-pop-white">
            답 제출하기
          </button>
        </form>
      </div>
    );
  };
  
  const renderCardModal = () => {
    if (!showCardModal) return null;
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 shadow-2xl text-center w-full max-w-4xl">
                <h2 className="text-4xl mb-2 text-pop text-gray-800">정답! 아이템 카드 선택</h2>
                <p className="text-gray-600 mb-6 text-lg">세 장의 카드 중 하나를 선택해 특별한 효과를 받으세요!</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {availableCards.map(item => {
                        const { name, icon, description } = ITEM_DESCRIPTIONS[item];
                        return (
                            <button key={item} onClick={() => handleCardSelect(item)}
                                className="bg-yellow-100 border-4 border-yellow-300 rounded-2xl p-6 text-center flex flex-col items-center justify-between hover:bg-yellow-200 hover:border-yellow-400 transform hover:-translate-y-2 transition-all duration-300 shadow-lg">
                                <div className="text-8xl mb-4">{icon}</div>
                                <h3 className="text-3xl text-amber-800 mb-2 text-pop">{name}</h3>
                                <p className="text-gray-700 text-lg">{description}</p>
                            </button>
                        )
                    })}
                </div>
            </div>
        </div>
    );
  };

  const renderPlayerSelectionModal = (
    title: string,
    description: string,
    onSelect: (playerId: number) => void,
    onSubmit: () => void,
    selectedTarget: number | null,
    showModal: boolean
  ) => {
    if (!showModal) return null;
    const otherPlayers = players.filter(p => p.id !== currentPlayer.id);

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-8 shadow-2xl text-center transform scale-100 transition-all w-full max-w-md">
          <h2 className="text-4xl mb-4 text-pop">{title}</h2>
          <p className="mb-6 text-gray-700 text-lg">{description}</p>
          <div className="space-y-3 mb-6">
            {otherPlayers.map(p => (
              <button key={p.id} onClick={() => onSelect(p.id)}
                className={`w-full p-3 rounded-lg text-2xl font-semibold border-4 transition-all ${selectedTarget === p.id ? `${p.tailwindBg} text-white ${p.tailwindBorder}` : `${p.tailwindBorder} ${p.tailwindText} bg-white`}`}>
                {p.name} ({p.score}점)
              </button>
            ))}
          </div>
          <button onClick={onSubmit} disabled={selectedTarget === null} className="w-full bg-green-400 hover:bg-green-500 text-white font-bold py-3 px-4 rounded-lg text-3xl disabled:bg-gray-400 disabled:cursor-not-allowed text-pop-white">
            확인
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-amber-100">
      {gameState === GameState.SETUP && renderGameSetup()}
      {gameState === GameState.PLAYING && renderGame()}
      {gameState === GameState.GAMEOVER && renderGameOver()}
      {renderQuestionModal()}
      {renderCardModal()}
      {renderPlayerSelectionModal('점수 교환!', '누구와 점수를 바꾸시겠습니까?', setSwapTarget, handleSwap, swapTarget, showSwapModal)}
      {renderPlayerSelectionModal('점수 뺏기!', '누구의 점수 2점을 뺏어오시겠습니까?', setStealTarget, handleStealScore, stealTarget, showStealScoreModal)}
    </div>
  );
};

export default App;
