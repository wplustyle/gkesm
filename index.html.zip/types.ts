export interface Fraction {
  numerator: number;
  denominator: number;
}

export interface MixedNumber {
  whole: number;
  numerator: number;
  denominator: number;
}

export interface Player {
  id: number;
  name: string;
  score: number;
  color: string;
  tailwindBg: string;
  tailwindText: string;
  tailwindBorder: string;
}

export enum ItemType {
  CLAIM_EMPTY = 'CLAIM_EMPTY',
  STEAL_TILE = 'STEAL_TILE',
  DOUBLE_POINTS = 'DOUBLE_POINTS',
  TRIPLE_POINTS = 'TRIPLE_POINTS',
  BOMB = 'BOMB',
  SWAP_SCORES = 'SWAP_SCORES',
  STEAL_SCORE = 'STEAL_SCORE',
}

export interface Problem {
  operand1: number | Fraction;
  operand2: Fraction;
  answer: MixedNumber;
}

export interface Tile {
  id: number;
  problem: Problem;
  ownerId: number | null;
}

export enum GameState {
  SETUP,
  PLAYING,
  GAMEOVER,
}
